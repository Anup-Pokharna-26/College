package com.example.palindrome;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText StringTextBox;
    String str1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void isPalindrome(View v){
        StringTextBox = findViewById(R.id.string1);
        str1 = StringTextBox.getText().toString();
        int res =1;
        int size = str1.length();
        int i,j;
        for(i=0;i<=size/2;i++){
            if(str1.charAt(i) != str1.charAt(size-i-1)){
                res = 0;
                break;

            }

        }
        Intent intent1 = new Intent(getApplicationContext(),Result.class);
        String resStr="IS PALINDROME";
        if(res == 0){
            resStr = "NOT PALINDROME";
        }
        intent1.putExtra("result",resStr);

        startActivity(intent1);
    }
}