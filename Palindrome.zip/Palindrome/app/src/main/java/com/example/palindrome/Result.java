package com.example.palindrome;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class Result extends Activity {
    TextView Result;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        Result = findViewById(R.id.res);

        String str1 = getIntent().getStringExtra("result");

        Result.setText(str1);
    }
}
