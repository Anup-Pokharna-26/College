package com.example.implictapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }


    public void openChrome(View view){
        String url = "https://www.google.com";
        Uri uri = Uri.parse(url);

        Intent i = new Intent(Intent.ACTION_VIEW,uri);
        startActivity(i);
    }


    public void contactMe(View view){
        String url = "tel:124567";
        Uri uri = Uri.parse(url);

        Intent i = new Intent(Intent.ACTION_DIAL,uri);
        startActivity(i);
    }

    public void myLoc(View view){
        String url = "geo:37,-112";
        Uri uri = Uri.parse(url);

        Intent i = new Intent(Intent.ACTION_VIEW,uri);
        startActivity(i);
    }
}