package com.example.first;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Date;


public class MainActivity extends Activity {
    String username,password,tag = "Event";
    Button login;
    EditText userNameTextBox,passwordTextBox,nameTextBox,emailTextBox,DOBBox;

    String DOB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(tag,"In the onCreate()");
        userNameTextBox = findViewById(R.id.Username);
        passwordTextBox = findViewById(R.id.Password);
        emailTextBox = findViewById(R.id.email);
        nameTextBox  =findViewById(R.id.Name);
        DOBBox = findViewById(R.id.DOB);
        login = findViewById(R.id.Login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username = userNameTextBox.getText().toString();
                password = passwordTextBox.getText().toString();
                DOB = DOBBox.getText().toString();


                if (username.equals(password)){
                    Intent i = new Intent(getApplicationContext(),LoginActivity.class);

                    i.putExtra("uname",username);
                    i.putExtra("name",nameTextBox.getText().toString());
                    i.putExtra("email",emailTextBox.getText().toString());
                    i.putExtra("DOB",DOB);

                    startActivity(i);
                }
            }
        });
    }
    protected void onStart() {
        super.onStart();

        Log.d(tag,"In the Start()");

    }
    protected void onPause() {
        super.onPause();

        Log.d(tag,"OnPause()");

    }
    protected void onStop() {
        super.onStop();

        Log.d(tag,"In the Stop()");

    }
    protected void onResume() {
        super.onResume();

        Log.d(tag,"In the Resume()");

    }
    protected void onRestart() {
        super.onRestart();

        Log.d(tag,"In the Restart()");

    }
    protected void onDestroy() {
        super.onDestroy();

        Log.d(tag,"In the Destroy()");

    }

}