package com.example.first;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class LoginActivity extends Activity {
    TextView DobBox,txt,name,email;
    String DOB,Username,Email,Name ;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intent);
        Username = getIntent().getStringExtra("uname");
        txt = findViewById(R.id.target);
        DobBox = findViewById(R.id.DOB);
        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        txt.setText("Hello "+Username);
        Name = getIntent().getStringExtra("name");
        Email = getIntent().getStringExtra("email");
        DOB = getIntent().getStringExtra("DOB");
        name.setText(Name);
        email.setText(Email);
        DobBox.setText(DOB);
        Log.d("username",Username);




    }
}
